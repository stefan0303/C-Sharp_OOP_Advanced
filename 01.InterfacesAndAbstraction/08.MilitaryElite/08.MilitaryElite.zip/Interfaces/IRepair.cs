﻿public interface IRepair
{
    string Name { get; }

    int Hours { get; }
}