﻿public interface ISoldier
{
    string ID { get; }
    string FirstName { get; }
    string LastName { get; }
}