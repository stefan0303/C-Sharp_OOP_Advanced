﻿
public interface ICar
{
    string Brakes();
    string Gas();
}

