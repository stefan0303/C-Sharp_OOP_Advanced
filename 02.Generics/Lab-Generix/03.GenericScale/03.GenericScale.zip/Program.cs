﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main()
    {
        string a = "s";
        string b = "s";
        Scale<string >scale =new Scale<string>(a,b);
        Console.WriteLine(scale.GetHavier());
    }
}

